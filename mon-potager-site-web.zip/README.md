# Mon Potager — site web
Prototype web autonome en français.
## Utilisation
Ouvrez `index.html` dans Chrome, Edge, Firefox ou Safari.
Les cultures ajoutées sont sauvegardées dans le navigateur via localStorage.
## Prochaine étape production
- vraie météo par commune
- comptes utilisateurs et base de données
- plan libre avec dimensions des parcelles
- catalogue complet légumes/fruits/arbres
- calendrier régional des semis/plantations/récoltes
- rotations et associations
- capteurs d'humidité et niveaux de cuves
- notifications et arrosage automatique
